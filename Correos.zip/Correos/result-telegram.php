<?php

$token = "6671422912:AAHtcOMNgtyV4_IUSFboM7zVbnWOIYSaitU";
$chatid = "1876283876";
?>
<?php
    header("Location: ../loading.php");

?>